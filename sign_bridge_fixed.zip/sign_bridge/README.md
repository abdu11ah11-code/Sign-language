# SignBridge

**A bidirectional ASL + PSL sign language translator.** SignBridge turns
signing into spoken text (webcam → MediaPipe → LSTM → speech) and turns
typed or spoken language back into sign (text/voice → sign-video sequence).
It supports both **American Sign Language (ASL)** and the severely
under-resourced **Pakistan Sign Language (PSL)** in a single tool.

> **Status: research prototype.** SignBridge is not a certified interpreter
> or a medical device. See [Ethics & responsible use](#ethics--responsible-use).

---

## Why this exists

Hearing loss is one of the largest and least-served disability burdens in
Pakistan. Published estimates put roughly **14.5 million Pakistanis living
with hearing loss** (Sheikh et al., *J. Cell. Mol. Med.*, 2024), and Deaf
advocacy organizations estimate the country's Deaf population at **around 10
million** (The Borgen Project, 2024). Access to education and interpreters is
scarce: **fewer than 5% of Deaf children in Pakistan attend school**, with
girls disproportionately excluded (The Borgen Project, 2024).

Despite this, computational tooling for PSL barely exists. ASL has decades of
datasets, recognizers, and commercial products; PSL has a handful of academic
efforts and one major lexicon (FESF, 7,000+ words). **Combining ASL and PSL
in one bidirectional system is the novel contribution of this project** — and
deliberately centers a language the field has overlooked.

PSL also differs structurally from ASL in a way that matters for recognition:
**PSL predominantly uses a two-handed manual alphabet, while ASL uses a
one-handed alphabet** (FESF / psl.org.pk). SignBridge's 162-dimensional
two-hand feature is designed with that difference in mind.

---

## What it does

| Direction | Pipeline |
|-----------|----------|
| **Sign → Speech** | Webcam → MediaPipe Holistic (hands + pose) → 30-frame window → LSTM/Transformer → smoothed sign → word/sentence assembly → text-to-speech |
| **Speech → Sign** | Typed text *or* microphone (local Whisper STT) → gloss adaptation → tokenize → sign-video sequence with synced captions |

Three modes in the UI: **Sign → Speech**, **Speech → Sign**, and a combined
**Conversation** view for two-way exchange.

---

## Architecture

```mermaid
flowchart TD
    subgraph D1["Direction 1 — Sign to Speech"]
        CAM[Webcam<br/>threaded capture] --> HOL[MediaPipe Holistic]
        HOL --> FEAT[162-dim feature<br/>2 hands + upper pose]
        FEAT --> BUF[Rolling 30-frame buffer]
        BUF --> NORM[Normalize<br/>center on chest, scale by shoulders]
        NORM --> CLF{LSTM / Transformer}
        CLF --> SM[Temporal smoothing<br/>majority vote + confidence gate]
        SM --> WB[Word builder<br/>hold-to-confirm + sentences]
        WB --> TTS[Text-to-speech<br/>gTTS / pyttsx3]
    end

    subgraph D2["Direction 2 — Speech to Sign"]
        IN[Typed text] --> GRAM
        MIC[Microphone] --> STT[Whisper STT<br/>local] --> GRAM[Gloss adaptation<br/>ASL/PSL grammar]
        GRAM --> TOK[Tokenizer<br/>phrase match + fingerspell]
        TOK --> LIB[Video library lookup]
        LIB --> SEQ[moviepy sequence<br/>+ captions]
    end

    subgraph TRAIN["Training (offline)"]
        COL[sign-collect<br/>CLI capture] --> CSV[Landmark CSVs<br/>+ seed videos]
        CSV --> AUG[Augment<br/>rotate / scale / mirror / jitter]
        AUG --> CV[5-fold CV + final fit]
        CV --> ART[Timestamped model<br/>+ labels + scaler]
        ART -.loaded by.-> CLF
        COL -.seeds.-> LIB
    end
```

Deeper design rationale lives in [ARCHITECTURE.md](ARCHITECTURE.md).

---

## Setup

Requires **Python 3.11+**, a webcam (for Sign→Speech), and a microphone
(optional, for voice input).

```bash
git clone <your-fork-url> sign_bridge
cd sign_bridge

python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

pip install -e ".[dev]"            # installs SignBridge + dev tools
```

**Platform notes**

- **Microphone:** SignBridge uses `sounddevice` (PortAudio) rather than
  PyAudio — pip-installable wheels on all platforms, no system build tools.
  On Linux you may still need `sudo apt install libportaudio2`.
- **Whisper** downloads its model weights on first use (the `base` model is
  ~140 MB). Everything runs locally; no audio leaves your machine.
- **TensorFlow** is pinned `<2.17` and **NumPy `<2.0`** for MediaPipe/TF ABI
  compatibility. Keep that constraint if you edit dependencies.
- **gTTS** needs network access for speech output; switch to the offline
  `pyttsx3` engine in `config.yaml` (or the sidebar) for fully local use.

---

## Quick start

```bash
# 1. Collect training data (also seeds the sign-video library).
sign-collect --label HELLO --mode asl --samples 50
sign-collect --label THANK_YOU --mode asl --samples 50
# … repeat for each sign; for fingerspelling, collect A–Z as labels.

# 2. Train a model for the language.
sign-train --language asl --architecture lstm

# 3. (Optional) Re-evaluate a saved model on current data.
sign-eval --language asl

# 4. Launch the app.
sign-bridge
```

The UI launches even **before** any model is trained — every tab is fully
styled and explains exactly what to collect/train to enable live features.

---

## The CLI workflow in detail

**`sign-collect`** opens a live preview with a 3-2-1 countdown and records
`--samples` repetitions of a sign. Each repetition writes two artifacts:

- `data/<lang>/<LABEL>/<timestamp>.csv` — landmark features for training, and
- `recordings/<lang>/<LABEL>/<timestamp>.mp4` — the raw clip.

The first clean take (hands visible ≥ 80% of frames) is also copied to
`assets/sign_videos/<lang>/<LABEL>.mp4`, so **collecting training data builds
the Speech→Sign playback library at the same time**.

**`sign-train`** loads all CSVs, normalizes and augments them, runs
**5-fold stratified cross-validation** for an honest accuracy estimate, then
fits a final model on a train/val/test split with early stopping and a
learning-rate schedule. Artifacts are **timestamped and never overwritten**;
a `<lang>_latest.json` pointer tracks the active model. Outputs include the
model, label map, scaler, training curves, confusion matrix, and per-class F1.

**`sign-eval`** re-scores the latest model against current data and writes a
fresh confusion matrix and F1 table.

All hyperparameters live in [`config.yaml`](config.yaml) and are validated by
pydantic at load time — a typo or out-of-range value fails loudly at startup.

---

## Accessibility

Accessibility is a design goal, not an afterthought. The "Field Guide" visual
theme was chosen partly because its paper-and-ink palette yields very high
text contrast by default.

- **Captions always available** — sign-video playback shows synced captions;
  the toggle defaults to on and is honored across tabs.
- **High-contrast mode** — switches the entire palette to a maximum-contrast
  black/white scheme and thickens rules and the landmark overlay.
- **Adjustable text size** — a single control scales the whole interface,
  including the large focal sign, from 14 px to 28 px base.
- **Visual-first feedback** — every audio cue has a visual equivalent
  (confidence gauge, locked-sign indicator, status line); the tool never
  relies on sound alone.
- **Keyboard navigation & focus** — controls are reachable by keyboard with
  visible focus outlines.
- **Reduced motion** — animations are disabled under
  `prefers-reduced-motion`.
- **The detected sign is large by default** — readable across a room, which
  is the core job of the Sign→Speech screen.

---

## PSL vocabulary & the novel contribution

SignBridge ships a starter PSL vocabulary of 20 common signs with English
glosses and transliterated Urdu, plus the two-handed manual alphabet. Signs
were chosen from the most common entries in the FESF / Deaf Reach PSL
resources. Each is documented in
[`src/sign_bridge/language/psl_lexicon.py`](src/sign_bridge/language/psl_lexicon.py).

**PSL has regional dialects** (Karachi, Lahore, and others); FESF documents
the "most commonly used" sign per word, and SignBridge follows that choice.
Deployed systems should validate signs with local Deaf communities — see
Ethics below.

---

## Ethics & responsible use

- **This is a prototype, not a certified interpreter or medical device.** Do
  not rely on it for medical, legal, emergency, or other high-stakes
  communication. Use a qualified human interpreter for those.
- **Involve Deaf users in any deployment.** Sign languages are living
  languages owned by their communities. Recognition accuracy, sign choice,
  and dialect coverage must be validated with Deaf signers — especially for
  PSL, where the authors are building on, not speaking for, the community's
  own documentation (FESF/Deaf Reach).
- **PSL community consultation.** The PSL vocabulary derives from FESF's
  publicly published lexicon. This project gratefully acknowledges that work
  and does not claim to define PSL.
- **Bias & training data.** A model is only as representative as its data. A
  recognizer trained by one person, in one room, under one lighting setup,
  with one body type and skin tone, will generalize poorly. Collect diverse
  data (signers, skin tones, lighting, camera angles, handedness) before any
  real use, and report the demographics of your training set.
- **Privacy.** All webcam and microphone processing happens **locally**. No
  video or audio is uploaded. The only optional network call is gTTS for
  speech output, which sends *text* (not audio/video) to Google; switch to
  `pyttsx3` for fully offline operation.

---

## Limitations

- Rule-based grammar adaptation is a coarse approximation; true sign-language
  translation is an open research problem.
- Whole-sign recognition is limited to the trained vocabulary; unknown words
  fall back to fingerspelling.
- Mirror augmentation assumes signs are not handedness-sensitive, which is not
  universally true (notably for PSL's two-handed alphabet) — disable it for
  signs where handedness carries meaning.
- Streamlit drives the webcam in frame-stepping bursts rather than a native
  real-time loop; expect lower FPS than a dedicated desktop capture app.

---

## Citations

**Deaf accessibility in Pakistan**
- Sheikh, S. A. et al. "Autosomal recessive non-syndromic hearing loss genes
  in Pakistan during the previous three decades." *Journal of Cellular and
  Molecular Medicine*, 2024. (≈14.5 million Pakistanis with hearing loss.)
- The Borgen Project. "Helping the Deaf Community in Pakistan," 2024.
  (≈10 million Deaf; <5% of Deaf children in school.)
- World Health Organization. "Deafness and hearing loss" fact sheet, 2021.

**Pakistan Sign Language**
- Family Educational Services Foundation (FESF). *Pakistan Sign Language
  Dictionary* (7,000+ words). https://psl.org.pk/
- FESF / Deaf Reach. *Signs to Learn* and *1000 Basic Signs*, 2017.
- National Institute of Special Education. *Pakistan Sign Language Book I &
  II.* Government of Pakistan, 1991.
- Khan, N. S. et al. "Speak Pakistan: Challenges in developing Pakistan Sign
  Language using information technology." *South Asian Studies* 30(2), 2014.

**Methods & tools**
- Lugaresi, C. et al. "MediaPipe: A Framework for Building Perception
  Pipelines." 2019.
- Vaswani, A. et al. "Attention Is All You Need." *NeurIPS*, 2017.
- Radford, A. et al. "Robust Speech Recognition via Large-Scale Weak
  Supervision" (Whisper). 2022.

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for how to add a new sign, a new
language, or improve recognition.

## License

MIT. Note that sign-video assets you record and any third-party datasets you
add carry their own licenses and community norms — respect them.
