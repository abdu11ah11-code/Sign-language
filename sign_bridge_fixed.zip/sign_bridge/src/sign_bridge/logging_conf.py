"""Structured JSON logging for SignBridge.

Call :func:`configure_logging` once at process start (CLIs and the UI do
this), then ``log = get_logger(__name__)`` anywhere. Output is one JSON
object per line — machine-parseable, grep-friendly, and safe to ship to
any log aggregator.
"""

from __future__ import annotations

import logging
import sys

import structlog


def configure_logging(level: int = logging.INFO) -> None:
    """Configure stdlib + structlog for JSON output to stderr.

    Args:
        level: Minimum log level (stdlib constant, e.g. ``logging.DEBUG``).
    """
    logging.basicConfig(stream=sys.stderr, level=level, format="%(message)s")
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
        logger_factory=structlog.PrintLoggerFactory(sys.stderr),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str) -> structlog.stdlib.BoundLogger:
    """Return a bound structlog logger named after the calling module."""
    logger: structlog.stdlib.BoundLogger = structlog.get_logger(name)
    return logger
