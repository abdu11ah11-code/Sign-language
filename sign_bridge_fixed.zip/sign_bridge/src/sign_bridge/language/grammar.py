"""Lightweight English→sign-gloss grammar adaptation.

Signed languages are NOT word-for-word English. ASL and PSL both tend to
use topic–comment ordering, place time markers first, and omit English
function words (articles, the copula "to be"). This module applies a small,
transparent set of rules to reorder/clean an English token stream before it
is sent to the video sequencer, producing more natural sign output.

This is deliberately simple and rule-based — a documented limitation. Full
sign-language MT is an open research problem; the goal here is "better than
raw English word order", not linguistic perfection. Real deployments should
involve Deaf signers in evaluating output (see README §Ethics).
"""

from __future__ import annotations

# English function words that are typically dropped in ASL/PSL glossing.
_DROP = {"a", "an", "the", "is", "are", "am", "be", "to", "of", "do", "does"}

# Time words conventionally move to the front of the clause.
_TIME = {
    "today", "tomorrow", "yesterday", "now", "later", "tonight",
    "morning", "evening", "night", "week", "month", "year",
}

# WH-words conventionally move to the end in ASL question structure.
_WH = {"what", "where", "who", "when", "why", "which", "how"}


def adapt_to_gloss(words: list[str]) -> list[str]:
    """Reorder/clean an English word list toward sign-gloss order.

    Rules, applied in order:
        1. Drop English function words that have no sign equivalent.
        2. Move time words to the front (ASL/PSL time-topic ordering).
        3. Move a WH-word to the end (common question structure).

    Args:
        words: Lowercased English words (no punctuation).

    Returns:
        A new, reordered list of glossable words. Casing is preserved as
        received; callers typically pass lowercase and uppercase later.
    """
    kept = [w for w in words if w.lower() not in _DROP]

    time_words = [w for w in kept if w.lower() in _TIME]
    rest = [w for w in kept if w.lower() not in _TIME]

    wh_words = [w for w in rest if w.lower() in _WH]
    non_wh = [w for w in rest if w.lower() not in _WH]

    return [*time_words, *non_wh, *wh_words]
