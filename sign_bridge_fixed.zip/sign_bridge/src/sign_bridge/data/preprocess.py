"""Landmark preprocessing: normalization, resampling, dataset assembly.

Pipeline (mirrors README architecture diagram):

    raw CSV clips ──resample──▶ (30, 162) windows ──normalize──▶ model input

Normalization (per frame):
    1. Center: subtract the chest point = midpoint of the two shoulders.
       Signs become translation-invariant (signer can stand anywhere).
    2. Scale: divide by shoulder width. Signs become distance-invariant
       (signer can be near or far from the camera).
    Zero-filled landmarks (undetected hand) stay exactly zero so the model
    can learn "hand absent" as signal rather than seeing noise.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

from sign_bridge.capture.holistic import (
    FEATURE_DIM,
    LEFT_SHOULDER_OFFSET,
    RIGHT_SHOULDER_OFFSET,
)
from sign_bridge.logging_conf import get_logger
from sign_bridge.typing import NDArray

log = get_logger(__name__)

_EPS = 1e-6


# ── geometric normalization ──────────────────────────────────────────────
def normalize_frame(frame: NDArray) -> NDArray:
    """Center one 162-dim frame on the chest and scale by shoulder width.

    Args:
        frame: ``(162,)`` raw feature vector.

    Returns:
        ``(162,)`` normalized copy. If shoulders were not detected the
        frame is returned unchanged (cannot normalize without a reference).
    """
    ls = frame[LEFT_SHOULDER_OFFSET : LEFT_SHOULDER_OFFSET + 3]
    rs = frame[RIGHT_SHOULDER_OFFSET : RIGHT_SHOULDER_OFFSET + 3]
    if not (np.any(ls) or np.any(rs)):
        return frame.astype(np.float32, copy=True)

    center = (ls + rs) / 2.0
    scale = float(np.linalg.norm(ls[:2] - rs[:2]))
    scale = scale if scale > _EPS else 1.0

    pts = frame.reshape(-1, 3)
    detected = np.any(pts != 0.0, axis=1)  # keep zero-filled points at zero
    out = pts.copy()
    out[detected] = (pts[detected] - center) / scale
    return out.reshape(-1).astype(np.float32)


def normalize_window(window: NDArray) -> NDArray:
    """Apply :func:`normalize_frame` to every frame of a ``(T, 162)`` window."""
    return np.stack([normalize_frame(f) for f in window]).astype(np.float32)


# ── temporal resampling ──────────────────────────────────────────────────
def resample_clip(clip: NDArray, target_frames: int) -> NDArray:
    """Uniformly resample a clip to a fixed number of frames.

    Collector clips are ~60 frames (2 s); models consume 30. Uniform index
    selection preserves motion shape; clips shorter than the target are
    padded by repeating the final frame (hold), matching how a signer
    holds the final posture of a sign.

    Args:
        clip: ``(T, F)`` array, any T ≥ 1.
        target_frames: Output length.

    Returns:
        ``(target_frames, F)`` float32 array.
    """
    t = clip.shape[0]
    if t == target_frames:
        return clip.astype(np.float32)
    if t > target_frames:
        idx = np.linspace(0, t - 1, target_frames).round().astype(int)
        return clip[idx].astype(np.float32)  # type: ignore[no-any-return]
    pad = np.repeat(clip[-1:], target_frames - t, axis=0)
    return np.concatenate([clip, pad]).astype(np.float32)  # type: ignore[no-any-return]


# ── dataset loading ──────────────────────────────────────────────────────
@dataclass(frozen=True)
class Dataset:
    """A loaded, normalized training set.

    Attributes:
        x: ``(N, window, 162)`` float32 inputs.
        y: ``(N,)`` int class indices.
        labels: Sorted gloss names; index = class id.
    """

    x: NDArray
    y: NDArray
    labels: list[str]


def load_dataset(language_dir: Path, window_size: int = 30) -> Dataset:
    """Load all landmark CSVs under ``data/<lang>/<LABEL>/*.csv``.

    Each CSV holds one recorded clip: rows = frames, 162 columns.
    Clips are resampled to ``window_size`` frames and normalized.

    Args:
        language_dir: e.g. ``Path("data/asl")``.
        window_size: Frames per training window.

    Returns:
        :class:`Dataset` with stable, sorted label ordering.

    Raises:
        FileNotFoundError: If the directory has no labeled CSVs at all.
    """
    label_dirs = (
        sorted(d for d in language_dir.iterdir() if d.is_dir())
        if language_dir.is_dir()
        else []
    )
    xs: list[NDArray] = []
    ys: list[int] = []
    labels = [d.name for d in label_dirs if any(d.glob("*.csv"))]
    if not labels:
        raise FileNotFoundError(
            f"No training data under {language_dir}. "
            "Record some with: sign-collect --label HELLO --mode "
            f"{language_dir.name} --samples 50"
        )

    for class_id, label in enumerate(labels):
        files = sorted((language_dir / label).glob("*.csv"))
        for csv_path in files:
            clip = pd.read_csv(csv_path, header=None).to_numpy(dtype=np.float32)
            if clip.ndim != 2 or clip.shape[1] != FEATURE_DIM:
                log.warning("skipping_malformed_clip", path=str(csv_path), shape=clip.shape)
                continue
            window = normalize_window(resample_clip(clip, window_size))
            xs.append(window)
            ys.append(class_id)
        log.info("loaded_label", label=label, clips=len(files))

    x = np.stack(xs)
    y = np.asarray(ys, dtype=np.int64)
    log.info("dataset_loaded", samples=int(x.shape[0]), classes=len(labels))
    return Dataset(x=x, y=y, labels=labels)


# ── optional flattened scaler (second-stage standardization) ─────────────
def fit_scaler(x: NDArray) -> StandardScaler:
    """Fit a StandardScaler over all frames of all windows.

    Geometric normalization already does the heavy lifting; this final
    zero-mean/unit-variance pass helps optimization slightly and is kept
    for parity with the saved ``scalers.joblib`` artifact contract.
    """
    scaler = StandardScaler()
    scaler.fit(x.reshape(-1, x.shape[-1]))
    return scaler


def apply_scaler(x: NDArray, scaler: StandardScaler) -> NDArray:
    """Transform ``(N, T, F)`` windows with a fitted scaler, preserving shape."""
    n, t, f = x.shape
    return scaler.transform(x.reshape(-1, f)).reshape(n, t, f).astype(np.float32)  # type: ignore[no-any-return]


def save_scaler(scaler: StandardScaler, path: Path) -> None:
    """Persist a scaler with joblib (parents created)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(scaler, path)


def load_scaler(path: Path) -> StandardScaler:
    """Load a scaler saved by :func:`save_scaler`."""
    loaded: StandardScaler = joblib.load(path)
    return loaded


# ── label persistence ────────────────────────────────────────────────────
def save_labels(labels: list[str], path: Path) -> None:
    """Write the class-index→gloss mapping next to a model artifact."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(labels, indent=2), encoding="utf-8")


def load_labels(path: Path) -> list[str]:
    """Read labels written by :func:`save_labels`."""
    return list(json.loads(path.read_text(encoding="utf-8")))
