"""Landmark-space data augmentation.

All transforms operate on *normalized* windows ``(T, 162)`` (chest at the
origin, shoulder width = 1), which makes rotation/scale trivially correct:
they act around the origin. Zero-filled (undetected) landmarks are left at
exactly zero by every transform.

Transforms (config §augmentation):
    rotate   — ± in-plane rotation of (x, y); simulates camera tilt
    scale    — ± uniform scale; simulates distance variation
    mirror   — horizontal flip + left/right landmark swap; valid because
               the lexicons here are not handedness-sensitive (documented
               limitation in README — disable for signs where it matters)
    jitter   — random frame drop/duplicate then resample; simulates
               signing-speed variation
"""

from __future__ import annotations

import numpy as np

from sign_bridge.capture.holistic import (
    LEFT_HAND_SLICE,
    POSE_LANDMARK_INDICES,
    POSE_SLICE,
    RIGHT_HAND_SLICE,
)
from sign_bridge.data.preprocess import resample_clip
from sign_bridge.typing import NDArray

# Symmetric pose pairs (MediaPipe indices) → positions inside our pose block.
_POSE_POS = {idx: i for i, idx in enumerate(POSE_LANDMARK_INDICES)}
_SYMMETRIC_POSE_PAIRS: tuple[tuple[int, int], ...] = tuple(
    (_POSE_POS[a], _POSE_POS[b])
    for a, b in ((2, 5), (11, 12), (13, 14), (15, 16), (23, 24))
)


def _detected_mask(window: NDArray) -> NDArray:
    """``(T, P)`` bool mask of points that are not zero-filled."""
    pts = window.reshape(window.shape[0], -1, 3)
    return np.any(pts != 0.0, axis=2)  # type: ignore[no-any-return]


def rotate(window: NDArray, degrees: float, rng: np.random.Generator) -> NDArray:
    """Rotate (x, y) of all detected points by a random angle in ±degrees."""
    theta = np.deg2rad(rng.uniform(-degrees, degrees))
    c, s = np.cos(theta), np.sin(theta)
    rot = np.array([[c, -s], [s, c]], dtype=np.float32)

    pts = window.reshape(window.shape[0], -1, 3).copy()
    mask = _detected_mask(window)
    xy = pts[..., :2]
    pts[..., :2] = np.where(mask[..., None], xy @ rot.T, xy)
    return pts.reshape(window.shape).astype(np.float32)


def scale(window: NDArray, pct: float, rng: np.random.Generator) -> NDArray:
    """Uniformly scale all detected points by a random factor in ±pct%."""
    factor = 1.0 + rng.uniform(-pct, pct) / 100.0
    pts = window.reshape(window.shape[0], -1, 3).copy()
    mask = _detected_mask(window)
    pts = np.where(mask[..., None], pts * factor, pts)
    return pts.reshape(window.shape).astype(np.float32)


def mirror(window: NDArray) -> NDArray:
    """Horizontally mirror a window: negate x, swap L/R hands and pose pairs."""
    out = window.copy()

    # Swap hand blocks wholesale.
    left = out[:, LEFT_HAND_SLICE].copy()
    out[:, LEFT_HAND_SLICE] = out[:, RIGHT_HAND_SLICE]
    out[:, RIGHT_HAND_SLICE] = left

    # Swap symmetric pose points.
    pose = out[:, POSE_SLICE].reshape(out.shape[0], -1, 3)
    for a, b in _SYMMETRIC_POSE_PAIRS:
        tmp = pose[:, a].copy()
        pose[:, a] = pose[:, b]
        pose[:, b] = tmp
    out[:, POSE_SLICE] = pose.reshape(out.shape[0], -1)

    # Negate x for every detected point.
    pts = out.reshape(out.shape[0], -1, 3)
    mask = _detected_mask(out)
    pts[..., 0] = np.where(mask, -pts[..., 0], pts[..., 0])
    return pts.reshape(window.shape).astype(np.float32)


def temporal_jitter(
    window: NDArray, max_frames: int, rng: np.random.Generator
) -> NDArray:
    """Randomly drop and duplicate up to ``max_frames``, then resample back."""
    if max_frames <= 0:
        return window.astype(np.float32)
    t = window.shape[0]
    k = int(rng.integers(0, max_frames + 1))
    if k == 0:
        return window.astype(np.float32)

    keep = np.sort(rng.choice(t, size=t - k, replace=False))
    jittered = window[keep]
    dup_idx = np.sort(rng.integers(0, jittered.shape[0], size=k))
    jittered = np.insert(jittered, dup_idx, jittered[dup_idx], axis=0)
    return resample_clip(jittered, t)


def augment_dataset(
    x: NDArray,
    y: NDArray,
    copies_per_sample: int = 2,
    rotation_deg: float = 15.0,
    scale_pct: float = 10.0,
    use_mirror: bool = True,
    jitter_frames: int = 3,
    seed: int = 42,
) -> tuple[NDArray, NDArray]:
    """Expand a dataset with randomized augmented copies.

    Args:
        x: ``(N, T, 162)`` normalized windows.
        y: ``(N,)`` labels.
        copies_per_sample: Augmented copies per original (0 = no-op).
        rotation_deg / scale_pct / use_mirror / jitter_frames: Transform
            magnitudes; see module docstring.
        seed: RNG seed for reproducible training sets.

    Returns:
        ``(x_aug, y_aug)`` — originals first, copies appended.
    """
    if copies_per_sample <= 0:
        return x, y
    rng = np.random.default_rng(seed)
    new_x: list[NDArray] = [x]
    new_y: list[NDArray] = [y]

    for _ in range(copies_per_sample):
        batch = []
        for window in x:
            w = rotate(window, rotation_deg, rng)
            w = scale(w, scale_pct, rng)
            if use_mirror and rng.random() < 0.5:
                w = mirror(w)
            w = temporal_jitter(w, jitter_frames, rng)
            batch.append(w)
        new_x.append(np.stack(batch))
        new_y.append(y.copy())

    return np.concatenate(new_x), np.concatenate(new_y)
