"""Text-to-speech wrapper for the sign→speech direction.

Two backends, selected in config (§tts.engine):

    gtts     — Google TTS; natural voices, needs network; returns MP3 bytes
               that the Streamlit UI can play with ``st.audio``.
    pyttsx3  — offline OS speech engine; speaks directly on the host. Useful
               for fully local/air-gapped demos; cannot return bytes for the
               browser, so the UI notes when audio plays on the server.

Both share the :class:`TextToSpeech` interface so callers stay backend-
agnostic.
"""

from __future__ import annotations

import io

from sign_bridge.logging_conf import get_logger

log = get_logger(__name__)


class TextToSpeech:
    """Backend-agnostic TTS facade.

    Args:
        engine: ``"gtts"`` or ``"pyttsx3"``.
        gtts_lang: Language code for gTTS (e.g. ``"en"``, ``"ur"``).
        pyttsx3_rate: Words-per-minute for the offline engine.
    """

    def __init__(
        self,
        engine: str = "gtts",
        gtts_lang: str = "en",
        pyttsx3_rate: int = 170,
    ) -> None:
        self._engine = engine
        self._gtts_lang = gtts_lang
        self._rate = pyttsx3_rate

    def to_mp3_bytes(self, text: str) -> bytes | None:
        """Synthesize speech and return MP3 bytes (gTTS only).

        Args:
            text: Text to speak.

        Returns:
            MP3 bytes for browser playback, or None if the active engine
            cannot produce bytes (pyttsx3) or text is empty.
        """
        text = text.strip()
        if not text:
            return None
        if self._engine != "gtts":
            return None
        try:
            from gtts import gTTS

            buffer = io.BytesIO()
            gTTS(text=text, lang=self._gtts_lang).write_to_fp(buffer)
            buffer.seek(0)
            log.info("tts_synthesized", chars=len(text), engine="gtts")
            return buffer.read()
        except Exception as exc:  # network/voice errors shouldn't crash the UI
            log.warning("tts_failed", error=str(exc))
            return None

    def speak_blocking(self, text: str) -> bool:
        """Speak on the host machine (pyttsx3). Blocks until done.

        Args:
            text: Text to speak.

        Returns:
            True on success, False on failure or empty text.
        """
        text = text.strip()
        if not text:
            return False
        try:
            import pyttsx3

            engine = pyttsx3.init()
            engine.setProperty("rate", self._rate)
            engine.say(text)
            engine.runAndWait()
            engine.stop()
            log.info("tts_spoken", chars=len(text), engine="pyttsx3")
            return True
        except Exception as exc:
            log.warning("tts_speak_failed", error=str(exc))
            return False
