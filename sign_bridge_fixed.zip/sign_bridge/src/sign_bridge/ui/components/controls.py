"""Sidebar controls and shared session-state helpers.

Houses the global controls that apply across all three tabs: language
(ASL/PSL), accessibility settings (high contrast, base font size, always-on
captions), and audio behavior (auto-speak, TTS engine). Also centralizes
Streamlit ``session_state`` initialization so every tab reads consistent
keys.
"""

from __future__ import annotations

from typing import Any

import streamlit as st

from sign_bridge.config import AppConfig


def init_state(config: AppConfig) -> None:
    """Initialize session-state defaults once per session.

    Args:
        config: Loaded application config providing initial values.
    """
    defaults: dict[str, Any] = {
        "language": config.app.default_language,
        "high_contrast": config.ui.high_contrast_default,
        "base_font_px": config.ui.base_font_px,
        "captions_on": config.ui.captions_always_on,
        "auto_speak": False,
        "transcript": [],          # list[tuple[timestamp_str, sentence]]
        "running": False,          # camera loop active
        "tts_engine": config.tts.engine,
    }
    for key, value in defaults.items():
        st.session_state.setdefault(key, value)


def sidebar(config: AppConfig) -> None:
    """Render the global sidebar; writes selections into session_state.

    Args:
        config: Loaded application config (for available options).
    """
    with st.sidebar:
        st.markdown('<div class="fg-label">Language</div>', unsafe_allow_html=True)
        lang = st.radio(
            "Sign language",
            options=["asl", "psl"],
            format_func=lambda x: "ASL — American" if x == "asl" else "PSL — Pakistan",
            index=0 if st.session_state["language"] == "asl" else 1,
            label_visibility="collapsed",
        )
        st.session_state["language"] = lang

        st.markdown('<div class="fg-label">Accessibility</div>', unsafe_allow_html=True)
        st.session_state["high_contrast"] = st.toggle(
            "High-contrast mode", value=st.session_state["high_contrast"],
            help="Maximum contrast palette and heavier rules for low vision.",
        )
        st.session_state["base_font_px"] = st.slider(
            "Text size", min_value=14, max_value=28,
            value=st.session_state["base_font_px"], step=1,
            help="Scales the entire interface, including the detected sign.",
        )
        st.session_state["captions_on"] = st.toggle(
            "Captions always on", value=st.session_state["captions_on"],
            help="Keep captions visible during sign-video playback.",
        )

        st.markdown('<div class="fg-label">Audio</div>', unsafe_allow_html=True)
        st.session_state["auto_speak"] = st.toggle(
            "Auto-speak sentences", value=st.session_state["auto_speak"],
            help="Speak each sentence aloud as soon as it is finalized.",
        )
        st.session_state["tts_engine"] = st.selectbox(
            "Voice engine", options=["gtts", "pyttsx3"],
            index=0 if st.session_state["tts_engine"] == "gtts" else 1,
            format_func=lambda e: "Google TTS (online)" if e == "gtts"
            else "Offline (server speakers)",
        )

        st.markdown(
            '<div class="fg-tagline" style="margin-top:1rem">'
            "Prototype — not a certified interpreter. See README §Ethics."
            "</div>",
            unsafe_allow_html=True,
        )
