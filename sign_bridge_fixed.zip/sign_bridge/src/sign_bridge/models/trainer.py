"""``sign-train`` — train a sign classifier for one language.

Usage:
    sign-train --language asl --architecture lstm
    sign-train --language psl --architecture transformer

Pipeline: load CSVs → normalize → augment (train folds only) → 5-fold
stratified CV for an honest accuracy estimate → final fit on a train/val
split with early stopping + LR schedule → evaluate on a held-out test set.

Artifacts (timestamped — existing models are never overwritten):
    models/<lang>_<arch>_<ts>.keras       trained model
    models/<lang>_<arch>_<ts>.labels.json class-index → gloss
    models/<lang>_<arch>_<ts>.scaler.joblib
    models/<lang>_<arch>_<ts>.curves.png  loss/accuracy curves
    models/<lang>_<arch>_<ts>.metrics.json
    models/<lang>_latest.json             pointer consumed by inference
"""

from __future__ import annotations

import argparse
import json
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import numpy as np

from sign_bridge.config import AppConfig, load_config
from sign_bridge.data.augment import augment_dataset
from sign_bridge.data.preprocess import (
    Dataset,
    apply_scaler,
    fit_scaler,
    load_dataset,
    save_labels,
    save_scaler,
)
from sign_bridge.logging_conf import configure_logging, get_logger
from sign_bridge.typing import NDArray

log = get_logger(__name__)


def _build(architecture: str, num_classes: int, cfg: AppConfig) -> Any:
    """Construct the requested architecture from config hyperparameters."""
    if architecture == "transformer":
        from sign_bridge.models.transformer_clf import build_transformer

        t = cfg.model.transformer
        return build_transformer(
            num_classes=num_classes,
            window_size=cfg.landmarks.window_size,
            feature_dim=cfg.landmarks.feature_dim,
            d_model=t.d_model,
            num_heads=t.num_heads,
            ff_dim=t.ff_dim,
            num_blocks=t.num_blocks,
            dropout=cfg.model.dropout,
            learning_rate=cfg.training.learning_rate,
        )
    from sign_bridge.models.lstm_classifier import build_lstm

    return build_lstm(
        num_classes=num_classes,
        window_size=cfg.landmarks.window_size,
        feature_dim=cfg.landmarks.feature_dim,
        lstm_units=cfg.model.lstm_units,
        dense_units=cfg.model.dense_units,
        dropout=cfg.model.dropout,
        learning_rate=cfg.training.learning_rate,
    )


def _callbacks(cfg: AppConfig) -> list[Any]:
    from tensorflow import keras

    return [
        keras.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=cfg.training.early_stopping_patience,
            restore_best_weights=True,
        ),
        keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss",
            patience=cfg.training.reduce_lr_patience,
            factor=cfg.training.reduce_lr_factor,
            verbose=0,
        ),
    ]


def _class_weights(y: NDArray) -> dict[int, float]:
    """Inverse-frequency class weights for imbalanced sign counts."""
    counts = np.bincount(y)
    total = counts.sum()
    return {i: float(total / (len(counts) * c)) for i, c in enumerate(counts) if c > 0}


def _augment(x: NDArray, y: NDArray, cfg: AppConfig) -> tuple[NDArray, NDArray]:
    if not cfg.training.augment:
        return x, y
    a = cfg.augmentation
    return augment_dataset(
        x, y,
        copies_per_sample=a.copies_per_sample,
        rotation_deg=a.rotation_deg,
        scale_pct=a.scale_pct,
        use_mirror=a.mirror,
        jitter_frames=a.temporal_jitter_frames,
        seed=cfg.training.seed,
    )


def cross_validate(ds: Dataset, architecture: str, cfg: AppConfig) -> list[float]:
    """K-fold CV accuracy. Augmentation/scaling are fit inside each fold —
    never on validation data — so the estimate is leak-free."""
    from sklearn.model_selection import StratifiedKFold

    skf = StratifiedKFold(
        n_splits=cfg.training.cv_folds, shuffle=True, random_state=cfg.training.seed
    )
    scores: list[float] = []
    for fold, (tr, va) in enumerate(skf.split(ds.x, ds.y), start=1):
        x_tr, y_tr = _augment(ds.x[tr], ds.y[tr], cfg)
        scaler = fit_scaler(x_tr)
        x_tr, x_va = apply_scaler(x_tr, scaler), apply_scaler(ds.x[va], scaler)

        model = _build(architecture, len(ds.labels), cfg)
        model.fit(
            x_tr, y_tr,
            validation_data=(x_va, ds.y[va]),
            epochs=cfg.training.epochs,
            batch_size=cfg.training.batch_size,
            class_weight=_class_weights(y_tr) if cfg.training.use_class_weights else None,
            callbacks=_callbacks(cfg),
            verbose=0,
        )
        _, acc = model.evaluate(x_va, ds.y[va], verbose=0)
        scores.append(float(acc))
        log.info("cv_fold_done", fold=fold, accuracy=round(acc, 4))
    return scores


def _plot_curves(history: Any, path: Path) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    for ax, metric in zip(axes, ("loss", "accuracy"), strict=True):
        ax.plot(history.history[metric], label="train", color="#1E5A45")
        ax.plot(history.history[f"val_{metric}"], label="val", color="#A8731E")
        ax.set_title(metric)
        ax.set_xlabel("epoch")
        ax.legend()
        ax.grid(alpha=0.3)
    fig.suptitle("SignBridge training curves")
    fig.tight_layout()
    fig.savefig(path, dpi=140)
    plt.close(fig)


def train(language: str, architecture: str, config_path: str | None = None) -> Path:
    """Full training run. Returns the saved model path."""
    from sklearn.model_selection import train_test_split

    cfg = load_config(config_path)
    np.random.seed(cfg.training.seed)
    import tensorflow as tf

    tf.random.set_seed(cfg.training.seed)

    ds = load_dataset(
        cfg.resolve(cfg.paths.data_dir) / language, cfg.landmarks.window_size
    )

    # 1) Honest CV estimate.
    t0 = time.monotonic()
    cv_scores = cross_validate(ds, architecture, cfg)
    log.info(
        "cv_summary",
        mean=round(float(np.mean(cv_scores)), 4),
        std=round(float(np.std(cv_scores)), 4),
    )

    # 2) Final model: train / val / test split.
    x_trval, x_te, y_trval, y_te = train_test_split(
        ds.x, ds.y, test_size=cfg.training.test_split,
        stratify=ds.y, random_state=cfg.training.seed,
    )
    x_tr, x_va, y_tr, y_va = train_test_split(
        x_trval, y_trval, test_size=cfg.training.validation_split,
        stratify=y_trval, random_state=cfg.training.seed,
    )
    x_tr, y_tr = _augment(x_tr, y_tr, cfg)
    scaler = fit_scaler(x_tr)
    x_tr, x_va, x_te = (apply_scaler(a, scaler) for a in (x_tr, x_va, x_te))

    model = _build(architecture, len(ds.labels), cfg)
    history = model.fit(
        x_tr, y_tr,
        validation_data=(x_va, y_va),
        epochs=cfg.training.epochs,
        batch_size=cfg.training.batch_size,
        class_weight=_class_weights(y_tr) if cfg.training.use_class_weights else None,
        callbacks=_callbacks(cfg),
        verbose=2,
    )

    # 3) Save timestamped artifacts.
    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    models_dir = cfg.resolve(cfg.paths.models_dir)
    models_dir.mkdir(parents=True, exist_ok=True)
    stem = models_dir / f"{language}_{architecture}_{stamp}"

    model_path = stem.with_suffix(".keras")
    model.save(model_path)
    save_labels(ds.labels, Path(f"{stem}.labels.json"))
    save_scaler(scaler, Path(f"{stem}.scaler.joblib"))
    _plot_curves(history, Path(f"{stem}.curves.png"))

    # 4) Held-out evaluation (confusion matrix + per-class F1).
    from sign_bridge.models.evaluator import evaluate

    report = evaluate(model, x_te, y_te, ds.labels, output_stem=stem)
    metrics = {
        "language": language,
        "architecture": architecture,
        "timestamp_utc": stamp,
        "cv_accuracy_mean": float(np.mean(cv_scores)),
        "cv_accuracy_std": float(np.std(cv_scores)),
        "test_accuracy": report["accuracy"],
        "test_macro_f1": report["macro_f1"],
        "n_samples": int(ds.x.shape[0]),
        "n_classes": len(ds.labels),
        "train_seconds": round(time.monotonic() - t0, 1),
    }
    Path(f"{stem}.metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    # 5) Update the "latest" pointer used by inference.
    pointer = models_dir / f"{language}_latest.json"
    pointer.write_text(
        json.dumps({"model": model_path.name, "stem": stem.name}, indent=2),
        encoding="utf-8",
    )
    summary = {k: v for k, v in metrics.items() if k != "language"}
    log.info("training_complete", model=str(model_path), **summary)
    print(f"\nSaved {model_path}")
    print(f"CV accuracy {metrics['cv_accuracy_mean']:.3f} ± {metrics['cv_accuracy_std']:.3f}"
          f" | test accuracy {metrics['test_accuracy']:.3f}")
    return model_path


def main() -> None:
    """Console entry point for ``sign-train``."""
    configure_logging()
    parser = argparse.ArgumentParser(prog="sign-train", description="Train a sign classifier.")
    parser.add_argument("--language", choices=["asl", "psl"], required=True)
    parser.add_argument("--architecture", choices=["lstm", "transformer"], default=None)
    parser.add_argument("--config", default=None)
    args = parser.parse_args()

    cfg = load_config(args.config)
    train(args.language, args.architecture or cfg.model.architecture, args.config)


if __name__ == "__main__":
    main()
