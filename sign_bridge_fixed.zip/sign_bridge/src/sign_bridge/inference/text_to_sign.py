"""Direction 2 — text → sign pipeline.

Converts English text (typed, or transcribed from speech via Whisper) into
a playable sequence of sign clips:

    text ─▶ grammar adapt ─▶ tokenize ─▶ resolve each token to a clip
         ─▶ (optional) moviepy concat with caption overlay

Resolution per token:
    SIGN          → whole-sign clip from the video library
    FINGERSPELL   → sequence of letter clips (skips letters with no clip)
    PUNCT         → a short pause (no clip)

If a whole-sign clip is missing, the word falls back to fingerspelling so
the system degrades gracefully instead of dropping content.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from sign_bridge.data.video_library import VideoLibrary
from sign_bridge.language.grammar import adapt_to_gloss
from sign_bridge.language.tokenizer import SignToken, Tokenizer, TokenKind
from sign_bridge.logging_conf import get_logger

log = get_logger(__name__)

_WORD_RE = re.compile(r"[A-Za-z']+|[.?!,]")


@dataclass(frozen=True)
class SignClip:
    """One playable element of the output sequence.

    Attributes:
        caption: Text shown while this element plays.
        video_path: Clip to play, or None for a pause.
        is_pause: True for punctuation gaps.
        is_fallback: True when a word was fingerspelled for lack of a sign.
    """

    caption: str
    video_path: Path | None
    is_pause: bool = False
    is_fallback: bool = False


@dataclass
class SignSequence:
    """A resolved text→sign plan.

    Attributes:
        clips: Ordered playable elements.
        missing: Letters/words that could not be rendered at all.
        gloss: The adapted gloss string (for the caption track / debugging).
    """

    clips: list[SignClip] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    gloss: str = ""


class TextToSignPipeline:
    """Resolves English text to a sign-clip sequence for a given language.

    Args:
        library: The :class:`VideoLibrary` for the active language.
        use_grammar: Apply ASL/PSL gloss reordering before tokenizing.
    """

    def __init__(self, library: VideoLibrary, use_grammar: bool = True) -> None:
        self._library = library
        self._use_grammar = use_grammar
        self._tokenizer = Tokenizer(set(library.available_signs()))

    def refresh(self) -> None:
        """Re-scan the library and rebuild the tokenizer (after new clips)."""
        self._library.refresh()
        self._tokenizer = Tokenizer(set(self._library.available_signs()))

    def plan(self, text: str) -> SignSequence:
        """Build a :class:`SignSequence` from input text (no rendering)."""
        words = [w for w in _WORD_RE.findall(text) if w not in ".?!,"]
        glossed = adapt_to_gloss(words) if self._use_grammar else words
        gloss_str = " ".join(w.upper() for w in glossed)

        tokens = self._tokenizer.tokenize(" ".join(glossed))
        seq = SignSequence(gloss=gloss_str)

        for tok in tokens:
            self._resolve_token(tok, seq)
        log.info("text_to_sign_planned", clips=len(seq.clips), missing=len(seq.missing))
        return seq

    def _resolve_token(self, tok: SignToken, seq: SignSequence) -> None:
        if tok.kind is TokenKind.PUNCT:
            seq.clips.append(SignClip(caption=tok.text, video_path=None, is_pause=True))
            return

        if tok.kind is TokenKind.SIGN and tok.gloss is not None:
            path = self._library.path_for(tok.gloss)
            if path is not None:
                seq.clips.append(SignClip(caption=tok.text, video_path=path))
                return
            # Whole-sign clip missing → fall back to fingerspelling.
            self._fingerspell(tok.text, seq)
            return

        # FINGERSPELL token.
        self._fingerspell(tok.text, seq)

    def _fingerspell(self, word: str, seq: SignSequence) -> None:
        for ch in word.upper():
            if not ch.isalpha():
                continue
            path = self._library.path_for_letter(ch)
            if path is not None:
                seq.clips.append(
                    SignClip(caption=f"{word} · {ch}", video_path=path, is_fallback=True)
                )
            else:
                seq.missing.append(ch)

    # ── optional rendering (requires moviepy) ────────────────────────────
    def render(
        self,
        sequence: SignSequence,
        output_path: Path,
        pause_seconds: float = 0.4,
        add_captions: bool = True,
    ) -> Path:
        """Stitch a sequence into one MP4 with caption overlays.

        Args:
            sequence: A plan from :meth:`plan`.
            output_path: Destination ``.mp4``.
            pause_seconds: Gap inserted for punctuation tokens.
            add_captions: Burn the caption text into each segment.

        Returns:
            The path written.

        Raises:
            ValueError: If the sequence has no playable clips.
        """
        from moviepy.editor import (  # local import: heavy, optional at runtime
            ColorClip,
            CompositeVideoClip,
            TextClip,
            VideoFileClip,
            concatenate_videoclips,
        )

        segments = []
        for clip in sequence.clips:
            if clip.is_pause or clip.video_path is None:
                segments.append(ColorClip(size=(640, 480), color=(13, 11, 8),
                                          duration=pause_seconds))
                continue
            video = VideoFileClip(str(clip.video_path)).resize((640, 480))
            if add_captions:
                caption = (
                    TextClip(clip.caption, fontsize=40, color="white",
                             font="DejaVu-Sans", method="caption", size=(620, None))
                    .set_position(("center", "bottom"))
                    .set_duration(video.duration)
                )
                video = CompositeVideoClip([video, caption])
            segments.append(video)

        if not segments:
            raise ValueError("Nothing to render: no playable clips in sequence.")

        output_path.parent.mkdir(parents=True, exist_ok=True)
        final = concatenate_videoclips(segments, method="compose")
        final.write_videofile(str(output_path), fps=24, codec="libx264",
                              audio=False, logger=None)
        final.close()
        log.info("sequence_rendered", path=str(output_path))
        return output_path
