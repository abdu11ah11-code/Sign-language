"""Direction 1 — sign → text pipeline.

Ties the pieces together for live recognition:

    frame ─▶ Holistic ─▶ 162-dim features ─▶ rolling buffer (window_size)
          every Nth frame ─▶ scale ─▶ model.predict ─▶ smoother
          stable + confident ─▶ WordBuilder ─▶ word / sentence

The caller (UI or a headless loop) feeds frames via :meth:`process_frame`
and reads the returned :class:`FrameOutcome` to render the current sign,
confidence, word being built, and any finalized sentence.
"""

from __future__ import annotations

import time
from collections import deque
from dataclasses import dataclass
from typing import Any

import numpy as np

from sign_bridge.capture.holistic import HolisticResult
from sign_bridge.config import AppConfig
from sign_bridge.data.preprocess import normalize_frame
from sign_bridge.inference.smoothing import PredictionSmoother
from sign_bridge.inference.word_builder import WordBuilder
from sign_bridge.logging_conf import get_logger
from sign_bridge.typing import NDArray

log = get_logger(__name__)


@dataclass(frozen=True)
class FrameOutcome:
    """Per-frame result for the UI to render.

    Attributes:
        current_sign: Smoothed majority label (may be unstable), or None.
        confidence: Confidence of that label in [0, 1].
        is_locked: True on the frame a sign locks into the word builder.
        locked_sign: The sign locked this frame, if any.
        current_word: Letters accumulated so far.
        pending_sentence: In-progress sentence text.
        finalized_sentence: Set on the frame a sentence completes.
        latency_ms: Inference latency for this frame (None if no predict ran).
    """

    current_sign: str | None
    confidence: float
    is_locked: bool
    locked_sign: str | None
    current_word: str
    pending_sentence: str
    finalized_sentence: str | None
    latency_ms: float | None


class SignToTextPipeline:
    """Stateful live sign→text recognizer for one language/model.

    Args:
        model: Trained Keras model.
        labels: Index → gloss mapping that matches ``model``.
        scaler: Fitted StandardScaler used at training time.
        config: Application config (inference + landmark sections).
    """

    def __init__(self, model: Any, labels: list[str], scaler: Any, config: AppConfig) -> None:
        self._model = model
        self._labels = labels
        self._scaler = scaler
        self._cfg = config
        win = config.landmarks.window_size
        self._buffer: deque[NDArray] = deque(maxlen=win)
        self._smoother = PredictionSmoother(
            lock_frames=config.inference.lock_frames,
            confidence_threshold=config.inference.confidence_threshold,
        )
        self._builder = WordBuilder(cooldown_frames=config.inference.cooldown_frames)
        self._frame_idx = 0
        self._last_hands_time = time.monotonic()
        self._sentence_open = False

    # ── main entry ───────────────────────────────────────────────────────
    def process_frame(self, result: HolisticResult) -> FrameOutcome:
        """Process one tracked frame and advance all state.

        Args:
            result: Output of :meth:`HolisticTracker.process`.

        Returns:
            A :class:`FrameOutcome` describing what to display now.
        """
        self._frame_idx += 1
        self._builder.tick()
        now = time.monotonic()

        # Hands absent → maybe finalize the sentence after the pause window.
        if not result.hands_visible:
            self._smoother.reset()
            self._builder.hands_lost()
            finalized = None
            if (
                self._sentence_open
                and now - self._last_hands_time >= self._cfg.inference.sentence_pause_seconds
            ):
                finalized = self._builder.end_sentence()
                self._sentence_open = False
                if finalized:
                    log.info("sentence_finalized", text=finalized)
            return FrameOutcome(
                current_sign=None, confidence=0.0, is_locked=False, locked_sign=None,
                current_word=self._builder.current_word,
                pending_sentence=self._builder.pending_sentence,
                finalized_sentence=finalized, latency_ms=None,
            )

        self._last_hands_time = now
        self._buffer.append(normalize_frame(result.features))

        # Only predict every Nth frame, once the buffer is full.
        run = (
            len(self._buffer) == self._buffer.maxlen
            and self._frame_idx % self._cfg.inference.predict_every_n_frames == 0
        )
        if not run:
            return FrameOutcome(
                current_sign=self._smoother_label(), confidence=self._smoother_conf(),
                is_locked=False, locked_sign=None,
                current_word=self._builder.current_word,
                pending_sentence=self._builder.pending_sentence,
                finalized_sentence=None, latency_ms=None,
            )

        label, confidence, latency_ms = self._predict()
        smoothed = self._smoother.update(label, confidence)

        locked_sign: str | None = None
        if smoothed.is_stable and smoothed.label is not None and self._builder.commit_sign(
            smoothed.label
        ):
            locked_sign = smoothed.label
            self._sentence_open = True
            self._smoother.reset()
            log.info("sign_locked", sign=locked_sign, confidence=round(confidence, 3))

        return FrameOutcome(
            current_sign=smoothed.label, confidence=smoothed.confidence,
            is_locked=locked_sign is not None, locked_sign=locked_sign,
            current_word=self._builder.current_word,
            pending_sentence=self._builder.pending_sentence,
            finalized_sentence=None, latency_ms=latency_ms,
        )

    # ── helpers ──────────────────────────────────────────────────────────
    def _predict(self) -> tuple[str, float, float]:
        window = np.stack(self._buffer)[None, ...]  # (1, T, F)
        flat = self._scaler.transform(window.reshape(-1, window.shape[-1]))
        window = flat.reshape(window.shape).astype(np.float32)
        t0 = time.monotonic()
        probs = self._model.predict(window, verbose=0)[0]
        latency_ms = (time.monotonic() - t0) * 1000.0
        idx = int(probs.argmax())
        return self._labels[idx], float(probs[idx]), latency_ms

    def _smoother_label(self) -> str | None:
        return self._smoother.latest[0]

    def _smoother_conf(self) -> float:
        return self._smoother.latest[1]

    # ── session control ──────────────────────────────────────────────────
    def force_end_sentence(self) -> str | None:
        """Manually finalize the current sentence (e.g. a UI button)."""
        self._sentence_open = False
        return self._builder.end_sentence()

    @property
    def builder(self) -> WordBuilder:
        """Access the underlying word builder (transcript, sentences)."""
        return self._builder

    def reset(self) -> None:
        """Reset all state for a fresh session."""
        self._buffer.clear()
        self._smoother.reset()
        self._builder.reset()
        self._frame_idx = 0
        self._sentence_open = False
