"""Tests for landmark feature extraction (no real MediaPipe needed)."""

from __future__ import annotations

import numpy as np

from sign_bridge.capture.holistic import (
    FEATURE_DIM,
    LEFT_HAND_SLICE,
    RIGHT_HAND_SLICE,
    extract_features,
)
from tests.conftest import FakeHolisticResults


def test_feature_dim_is_162() -> None:
    assert FEATURE_DIM == 162


def test_extract_full_detection_shape(fake_results: FakeHolisticResults) -> None:
    feats = extract_features(fake_results)
    assert feats.shape == (162,)
    assert feats.dtype == np.float32


def test_missing_left_hand_is_zero_filled() -> None:
    results = FakeHolisticResults(left=False, right=True, pose=True)
    feats = extract_features(results)
    assert np.all(feats[LEFT_HAND_SLICE] == 0.0)
    assert np.any(feats[RIGHT_HAND_SLICE] != 0.0)


def test_missing_pose_zero_fills_pose_block() -> None:
    results = FakeHolisticResults(left=True, right=True, pose=False)
    feats = extract_features(results)
    assert np.all(feats[126:162] == 0.0)


def test_no_detection_all_zero() -> None:
    results = FakeHolisticResults(left=False, right=False, pose=False)
    feats = extract_features(results)
    assert np.all(feats == 0.0)
